package edu.cuc.fraccionarios;
public class Fraccionario implements Comparable {
    //atricutos
    protected int numerador;
    protected int denominador;
    //contructores

    public Fraccionario(int numerador, int denominador) throws Exception {
        this.numerador = numerador;
        if (denominador == 0) {
            //lanzar una excepcion
            throw new Exception("el denominador esta en cero!!");
        } else {
            this.denominador = denominador;
        }
    }
    
    //getters y setters

    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) throws Exception {
        if (denominador == 0) {
            //lanzar una excepcion
            throw new Exception("el denominador esta en cero!!");
        } else {
            this.denominador = denominador;
        }
    }

    @Override
    public String toString() {
        return "Fraccionario{" + numerador + "/" + denominador + '}';
    }

    //metodos especificos de la clase
    public double valor() {
        //se ((double)) hace eso para asegurar que la divion sea de numeros reales y no enteros
        return ((double) this.numerador) / this.denominador;
    }

    public Fraccionario sumar(Fraccionario fraccionario02) throws Exception {
        int numeradorSuma = (this.numerador * fraccionario02.denominador)
                          + (this.denominador * fraccionario02.numerador);
        int denominadorSuma = this.denominador * fraccionario02.denominador;
        // es lo mismo = this.getDenominador() * fraccionario02.getDenominador();
        Fraccionario fraccionSuma = 
                new Fraccionario(numeradorSuma, denominadorSuma);
        
        return fraccionSuma;

        
    }
    
       public Fraccionario restar(Fraccionario fraccionario02) throws Exception {
        int numeradorResta = (this.numerador * fraccionario02.denominador)
                          - (this.denominador * fraccionario02.numerador);
        int denominadorResta = this.denominador * fraccionario02.denominador;
        // es lo mismo = this.getDenominador() * fraccionario02.getDenominador();
        Fraccionario fraccionResta = 
                new Fraccionario(numeradorResta, denominadorResta);
        
        return fraccionResta;

        
    }
       
       public Fraccionario multiplicar(Fraccionario fraccion02) throws Exception{
       return new Fraccionario(this.numerador * fraccion02.numerador,
                               this.denominador * fraccion02.denominador);
       }
    
       public Fraccionario dividir(Fraccionario fraccion02) throws Exception{
       return new Fraccionario(this.numerador * fraccion02.denominador,
                               this.denominador * fraccion02.numerador);
       }

    @Override
    public boolean esMayorQue(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean esIgualQue(Object obj) {
        if (obj != null && getClass() == obj.getClass()) {
            Fraccionario fraccion02  = (Fraccionario) obj;
            return this.valor() == fraccion02.valor();
        }else {
            return false;
        }
    }

    @Override
    public boolean esMenorQue(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
