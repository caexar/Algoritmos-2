package edu.cuc.fraccionarios;

import com.sun.istack.internal.logging.Logger;
import java.util.logging.Level;

public class PruebaFraccionarios {
    public static void main(String[] args) {

        try {
            Fraccionario fraccion01 = new Fraccionario(5, 6);
            Fraccionario fraccion02 = new Fraccionario(3, 6);
            Fraccionario fraccion03 = new Fraccionario(4, 6);
            System.out.println(fraccion01);
            System.out.println(fraccion02);
            System.out.println(fraccion03);
            System.out.println("valor 1: "+fraccion01.valor());
            System.out.println("valor 2: "+fraccion02.valor());
            System.out.println("valor 3: "+fraccion03.valor());
            //sumar
            System.out.println("sumar: "+fraccion01.sumar(fraccion02));
            //resta
            System.out.println("sumar: "+fraccion01.restar(fraccion02));
            //multiplicacion
            System.out.println("sumar: "+fraccion01.multiplicar(fraccion02));
            //divicion
            System.out.println("sumar: "+fraccion01.dividir(fraccion02));
            
            System.out.println("igualdad 1: "+fraccion01.esIgualQue(fraccion02));
            Fraccionario fraccion04 = new Fraccionario(5, 6);
            System.out.println("igualdad 2: "+fraccion01.esIgualQue(fraccion04));

        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(PruebaFraccionarios.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
