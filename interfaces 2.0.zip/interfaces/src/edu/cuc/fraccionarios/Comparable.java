package edu.cuc.fraccionarios;
public interface Comparable {
    //atrivuto
    //int salario: no acepta variables (atrivuto)
    boolean esMayorQue(Object obj);
    boolean esIgualQue(Object obj);
    boolean esMenorQue(Object obj);
}
