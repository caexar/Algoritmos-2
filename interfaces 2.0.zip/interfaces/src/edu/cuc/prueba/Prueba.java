package edu.cuc.prueba;

import edu.cuc.figura.Rectangulo;

public class Prueba {
    public static void main(String[] args) {
        
        
        Rectangulo rectangulo01 = new Rectangulo(20, 10);
        System.out.println(rectangulo01.getNumeroLados());
        System.out.println("area: "+rectangulo01.calcularArea());
        System.out.println(rectangulo01);
        System.out.println("perimetro: "+rectangulo01.calcularPerimetro());
        
        
    }
    
}
