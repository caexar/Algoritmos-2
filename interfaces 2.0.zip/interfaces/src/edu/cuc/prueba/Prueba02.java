package edu.cuc.prueba;

import edu.cuc.figura.Cuadrado;

public class Prueba02 {
    public static void main(String[] args) {
        Cuadrado cuadrado01 = new Cuadrado(15);
        System.out.println(cuadrado01);
        System.out.println("area: "+cuadrado01.calcularArea());
        System.out.println("perimetro: "+cuadrado01.calcularPerimetro());
    }
    
}
