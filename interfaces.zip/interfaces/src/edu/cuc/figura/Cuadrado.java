package edu.cuc.figura;

public class Cuadrado extends Rectangulo {
    protected double lado;

    public Cuadrado(double lado) {
        super(lado, lado);
        this.lado = lado;
    }
    
    //getter y setter

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
    
    //metodos

    
    
    
    @Override
    public String toString() {
        return "Cuadrado{" + "lado=" + lado + '}';
    }

    
    
    
    
    
    
    
    
    
}
