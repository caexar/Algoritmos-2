package edu.cuc.figura;

public abstract class Poligono {
    //atributos
    protected int numeroLados;
    protected String color;
    
    //constructor

    public Poligono(int numeroLados) {
        this.numeroLados = numeroLados;
    }
    
    public Poligono(int numeroLados, String color) {
        this.numeroLados = numeroLados;
        this.color = color;
    }
    
    //getter y setter

    public int getNumeroLados() {
        return numeroLados;
    }

    public void setNumeroLados(int numeroLados) {
        this.numeroLados = numeroLados;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Poligono{" + "numeroLados=" + numeroLados + ", color=" + color + '}';
    }
    
    public abstract double calcularArea();
    public abstract double calcularPerimetro();
           
    
    
}
